<html>
<head>
<title>Redait Media</title>
</head>
<body>
<h1 align="center">Buenos días, estudiantes </h1>
<br>
<div align="center">
<img src="playa2.jpg">
</div>
</body>
</html>